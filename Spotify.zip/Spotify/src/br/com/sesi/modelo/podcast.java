package br.com.sesi.modelo;

public class podcast extends pai{

}
