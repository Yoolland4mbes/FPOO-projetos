import java.util.Scanner;
public class Main {

	
		//DADOS PESSOAIS
	public static void main(String[] args) {
		Scanner objScanner = new Scanner(System.in);
		DadosPessoais objDadosPessoais = new DadosPessoais();
		DadosContatos objDadosContatos = new DadosContatos();
		DadosEnderecos objDadosEnderecos = new DadosEnderecos();
		
		System.out.println("INFORME O NOME");
		objDadosPessoais.setNome(objScanner.next());
		System.out.println("INFORME O SOBRENOME");
		objDadosPessoais.setSobreNome(objScanner.next());
		System.out.println("INFORME SUA DATA DE NASCIMENTO");
		objDadosPessoais.setDataNascimento(objScanner.next());
		System.out.println("INFORME SEU GENERO");
		objDadosPessoais.setGenero(objScanner.next());
		
		
		//DADOS CONTATOS
		System.out.println("INFORME SEU E-MAIL");
		objDadosContatos.setEmail(objScanner.next());
		System.out.println("INFORME SEU TELEFONE");
		objDadosContatos.setTelefone(objScanner.next());
		
		//DADOS ENDERE�O
		System.out.println("INFORME SEU CEP");
		objDadosEnderecos.setCep(objScanner.next());
		System.out.println("INFORME SEU LOGRADOURO");
		objDadosEnderecos.setLogradouro(objScanner.next());
		System.out.println("INFORME SEU NUMERO");
		objDadosEnderecos.setNumero(objScanner.next());
		System.out.println("INFORME SEU BAIRRO");
		objDadosEnderecos.setBairro(objScanner.next());
		System.out.println("INFORME SUA CIDADE");
		objDadosEnderecos.setCidade(objScanner.next());
		System.out.println("INFORME SEU ESTADO");
		objDadosEnderecos.setEstado(objScanner.next());
		
		
		
		
		
		
		
		
		
	}

}
