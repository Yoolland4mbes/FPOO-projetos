package br.com.sesi.app;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import br.com.sesi.modelo.musics;
import br.com.sesi.modelo.podcast;




public class Main{

	public static void main(String[] args) {
		
		 JFrame frame = new JFrame("Wanna help us?");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(100,100);

	        JButton button = new JButton("Like button!");
	        button.addActionListener(new ActionListener() {
	        	
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                // Add the action to be performed when the button is clicked
	                System.out.println("You liked the song! ");
	                System.out.println("You liked the podcast!");
	                System.out.println("Thank you for helping our app!");
	            }
	        });

	        frame.add(button);
	        frame.setVisible(true);
	        
	        
    
		
		musics Music1 = new musics();
		
		Music1.setTitle("1 por amor 2 por dinheiro");
		Music1.setRanking("#1st place in the ranking");
		Music1.setReproduction_time(270);
		Music1.setLength("06:59");
		Music1.setLikes(4920);
		Music1.setStars(4.5);
		Music1.setFavorites(4900);
		Music1.setArtist("Racionais mc's");

		System.out.println("Welcome to SPOTIFY");
		System.out.println("###############################################################");
		
		Music1.Info();
		System.out.println("Total reproduct time: " + Music1.getReproduction_time() + " Minutes/month");
		System.out.println("The song were liked by " + Music1.getLikes() + " people, and favorited by " + Music1.getFavorites() + " people" );
		System.out.println("Total of stars:  ⭐⭐⭐⭐ " + Music1.getStars() + " Stars");
		System.out.println("###############################################################");
		
   
		
		podcast Podcast1 = new podcast();
		Podcast1.setTitle("Podpah");
		Podcast1.setRanking("#1st place in the ranking");
		Podcast1.setReproduction_time(895);
		Podcast1.setLength("02:9");
		Podcast1.setLikes(7810);
		Podcast1.setStars(5);
		Podcast1.setFavorites(7390);
		Podcast1.setArtist("Igão e Mitico");
		
		
		Podcast1.Info();
		System.out.println("Total reproduct time: " + Podcast1.getReproduction_time() + " Minutes/month");
		System.out.println("The song were liked by " + Podcast1.getLikes() + " people, and favorited by " + Music1.getFavorites() + " people" );
		System.out.println("Total of stars:  ⭐⭐⭐⭐⭐ " + Podcast1.getStars() + " Stars");
		
		}	
}
