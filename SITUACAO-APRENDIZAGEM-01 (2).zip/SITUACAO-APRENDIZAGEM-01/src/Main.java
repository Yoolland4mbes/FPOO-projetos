
public class Main {
		
	public static void main(String[] args) {
		Menu objMenu = new Menu();
		objMenu.ExibirMenu();
	
		
		
		
		
		
	}

}
