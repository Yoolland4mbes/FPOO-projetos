package br.com.sesi.modelo;

public class pai {
	
	private String Title;
	
	protected String Artist;
	
	private String Ranking;
	
	protected String Length;
	
	protected double Reproduction_time;
	
	protected int Likes;
	
	protected double Stars;
	
	protected int Favorites;
	


	
	
	
	
	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	
	
	public String getArtist() {
		return Artist;
	}

	public void setArtist(String artist) {
		Artist = artist;
	}

	public String getLength() {
		return Length;
	}

	public void setLength(String length) {
		Length = length;
	}

	public double getReproduction_time() {
		return Reproduction_time;
	}

	public void setReproduction_time(double reproduction_time) {
		Reproduction_time = reproduction_time;
	}

	public int getLikes() {
		return Likes;
	}

	public void setLikes(int likes) {
		Likes = likes;
	}

	public double getStars() {
		return Stars;
	}

	public void setStars(double stars) {
		Stars = stars;
	}

	public int getFavorites() {
		return Favorites;
	}

	public void setFavorites(int favorites) {
		Favorites = favorites;
	}

	public String getRanking() {
		return Ranking;
	}

	public void setRanking(String ranking) {
		Ranking = ranking;
	}
	
	
	//METHODS 
	
	public void Info() {
		System.out.println("You are listening to: " + Title + ", From: " + Artist);
		System.out.println("This song was rated on the " + Ranking);
		System.out.println("You gonna listen this song for exactaly " + Length + " mins/hours" );
		
	}
	
	
	
	
	
	
	
	
	
	
}

